ini adalah tools yang dibuat untuk membuat paks versi diri sendiri
dan tools ini itu hanya untuk ekstrak pak aja 

cara menggunakan 
 1.apt upgrade
 2.pkg install git
 3.git clone https://github.com/TUNBudi06/thepakv4
 4.chmod +x theinstaller
 5.bash theinstaller
 
 
simplekan nah nanti otomatis tools atau program yang dibutuhkan 
akan terinstall sendiri
untuk menggunakan
1.bash setup
2.taruh paks pubg di folder download/pak
3.lalu pilih 
    1 untuk unpack
    2 untuk repack
4.setelah itu 5
6.untuk tutorial lebih lanjut ada di channel gw

videonya :